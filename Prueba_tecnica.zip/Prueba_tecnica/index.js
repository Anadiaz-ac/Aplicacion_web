import express from 'express' //importamos el framework express para crear el servidor
import { dirname,join } from 'path'
import { fileURLToPath } from 'url'
import indexRoute from "./Routes/routes.js"


const app = express() //inicizlizamos express
app.listen(3000) //inicializar el servidor


const __dirname = dirname(fileURLToPath(import.meta.url))  //le damos la ruta a la carpeta prueba_tecnica
app.set('views', join(__dirname, 'views')) //hacemos la union de la carpeta prueba_tecnica con view
app.set('view engine', 'ejs') //motor de plantillas
app.use(indexRoute)

