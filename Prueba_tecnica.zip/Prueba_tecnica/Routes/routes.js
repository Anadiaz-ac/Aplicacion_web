import { Router } from "express"
import {getData} from "../Controllers/controller.js"

const router = Router()

router.get('/', (req, res) => res.render('index')) //Ruta hacia la pagina principal

router.get('/detalle/:Cedula/:Nombre/:Apellidos/:Celular', (req, res) => res.render('detalle', {Cedula: req.params.Cedula, Nombre: req.params.Nombre, Apellido: req.params.Apellidos, Celular: req.params.Celular})) //Ruta hacia la pagina con más detalle

router.get('/GET', getData) //ruta donde se obtiene todos los datos tipo json


export default router