import conn from "../dbConnection/dbConn.js"

//Se realiza una consulta a la BD para traer todos los datos
export const getData =  async (req, res) => { 
    try{
    const [result] = await conn.query("SELECT * FROM cliente")
    res.json(result)
    }
    catch(error)
    {
        return res.status(500).json({message :"Algo salió mal"})
    }
}

