CREATE DATABASE clientes;

use clientes;

CREATE TABLE cliente(
	Cedula int primary key,
    Nombre varchar(30),
    Apellidos varchar(40),
    Celular varchar(10)
);

INSERT INTO cliente VALUES (100458748,"Jhoana","Lopez","3145897458");
INSERT INTO cliente VALUES (100687452,"Juan","Perez","3145894587");
INSERT INTO cliente VALUES (188745962,"Daniel","Calle","3141475458");
INSERT INTO cliente VALUES (108831251,"David","Cortes","3125797458");
INSERT INTO cliente VALUES (123893837,"Marisol","Diaz","314597458");
INSERT INTO cliente VALUES (100136897,"Lorena","Acevedo","3135897458");
INSERT INTO cliente VALUES (100462809,"Luz","Grisales","3055897458");
INSERT INTO cliente VALUES (42022247,"Camilo","Perez","3195897458");
INSERT INTO cliente VALUES (125896423,"Esteban","Vasquez","3155897458");


SELECT * FROM cliente;