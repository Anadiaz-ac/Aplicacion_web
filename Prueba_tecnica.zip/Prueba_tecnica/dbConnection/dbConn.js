import { createPool } from "mysql2/promise";

//Se llenan todos los datos necesarios para la conexion a la BD
const conn = createPool({
    host: 'localhost',
    user: 'root',
    password: 'anamaria0921',
    port: 3306,
    database: 'clientes'
})

export default conn
